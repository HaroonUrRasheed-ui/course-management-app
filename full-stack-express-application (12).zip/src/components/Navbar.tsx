import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { GraduationCap, LogOut, Plus, User, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const loc = useLocation();
  const [open, setOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); setOpen(false); };
  const act = (p: string) => loc.pathname === p;

  return (
    <nav className="bg-white/80 backdrop-blur-xl border-b border-stone-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2.5 group" onClick={() => setOpen(false)}>
            <div className="bg-orange-600 p-2 rounded-xl group-hover:bg-orange-500 transition-colors">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-extrabold text-stone-900 tracking-tight">Learn<span className="text-orange-600">Stack</span></span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            <Link to="/" className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${act('/') ? 'bg-stone-100 text-stone-900' : 'text-stone-500 hover:text-stone-900 hover:bg-stone-50'}`}>Home</Link>
            {isAuthenticated && (
              <>
                <Link to="/courses" className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${act('/courses') ? 'bg-stone-100 text-stone-900' : 'text-stone-500 hover:text-stone-900 hover:bg-stone-50'}`}>Courses</Link>
                <Link to="/courses/new" className="flex items-center gap-1.5 ml-2 px-4 py-2 rounded-lg text-sm font-semibold bg-orange-600 text-white hover:bg-orange-500 transition-colors shadow-sm">
                  <Plus className="w-4 h-4" /> New Course
                </Link>
              </>
            )}
          </div>

          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <div className="flex items-center gap-2 text-stone-600">
                  <div className="bg-orange-100 p-1.5 rounded-full"><User className="w-3.5 h-3.5 text-orange-600" /></div>
                  <span className="text-sm font-medium">{user?.username}</span>
                </div>
                <button onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-stone-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="px-4 py-2 rounded-lg text-sm font-medium text-stone-500 hover:text-stone-900 hover:bg-stone-50 transition-colors">Login</Link>
                <Link to="/register" className="px-5 py-2 rounded-lg text-sm font-semibold bg-orange-600 text-white hover:bg-orange-500 transition-colors shadow-sm">Register</Link>
              </>
            )}
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-100">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-stone-200 bg-white pb-4 px-4 pt-3 space-y-1">
          <Link to="/" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-stone-600 hover:bg-stone-50">Home</Link>
          {isAuthenticated && (
            <>
              <Link to="/courses" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-stone-600 hover:bg-stone-50">Courses</Link>
              <Link to="/courses/new" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm font-medium text-orange-600 hover:bg-orange-50">+ New Course</Link>
            </>
          )}
          <div className="border-t border-stone-100 pt-2 mt-2">
            {isAuthenticated ? (
              <>
                <div className="px-4 py-2 text-sm text-stone-400">Signed in as <span className="text-stone-700 font-medium">{user?.username}</span></div>
                <button onClick={handleLogout} className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-red-500 hover:bg-red-50">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm text-stone-600 hover:bg-stone-50">Login</Link>
                <Link to="/register" onClick={() => setOpen(false)} className="block px-4 py-2.5 rounded-lg text-sm font-medium text-orange-600 hover:bg-orange-50">Register</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
