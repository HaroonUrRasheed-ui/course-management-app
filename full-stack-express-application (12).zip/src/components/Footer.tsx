import { GraduationCap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-stone-200 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="bg-orange-100 p-2 rounded-xl"><GraduationCap className="w-4 h-4 text-orange-600" /></div>
            <span className="text-sm text-stone-500">LearnStack — Full Stack Express Application</span>
          </div>
          <div className="text-xs text-stone-400">
            <span className="hidden sm:inline">Node.js · Express · MongoDB · EJS · TailwindCSS · Passport.js</span>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-stone-100 text-center text-xs text-stone-400">
          Web Engineering Assignment &copy; {new Date().getFullYear()}
        </div>
      </div>
    </footer>
  );
}
