import { Link } from 'react-router-dom';
import { Star, Clock, Users, ArrowUpRight } from 'lucide-react';
import type { Course } from '../types';

const catEmoji: Record<string, string> = {
  'Web Development': '🌐', 'Data Science': '📊', Design: '🎨',
  'Cloud & DevOps': '☁️', 'Mobile Development': '📱', Security: '🔒',
  'AI & Machine Learning': '🤖', 'Game Development': '🎮',
  Database: '🗄️', Networking: '🌍',
};

const levelDot: Record<string, string> = {
  Beginner: 'bg-emerald-400', Intermediate: 'bg-amber-400', Advanced: 'bg-red-400',
};

export default function CourseCard({ course }: { course: Course }) {
  return (
    <Link
      to={`/courses/${course._id}`}
      className="group block bg-white rounded-2xl border border-stone-200 overflow-hidden hover:shadow-lg hover:shadow-stone-200/60 hover:border-stone-300 transition-all duration-300"
    >
      <div className="h-40 relative overflow-hidden bg-stone-50 flex items-center justify-center">
        <div
          className="w-18 h-18 rounded-2xl flex items-center justify-center text-4xl shadow-md group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-300"
          style={{ backgroundColor: course.color + '15', border: `2px solid ${course.color}25` }}
        >
          {catEmoji[course.category] || '📚'}
        </div>

        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2.5 py-1 rounded-full shadow-sm border border-stone-100">
          <span className="text-sm font-bold text-stone-800">${course.price.toFixed(2)}</span>
        </div>

        <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-white/90 backdrop-blur px-2 py-1 rounded-full shadow-sm border border-stone-100">
          <div className={`w-2 h-2 rounded-full ${levelDot[course.level]}`} />
          <span className="text-[11px] font-semibold text-stone-600">{course.level}</span>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-400">{course.category}</span>
        </div>

        <h3 className="text-[15px] font-semibold text-stone-800 leading-snug line-clamp-2 group-hover:text-orange-600 transition-colors min-h-[2.5rem]">
          {course.title}
        </h3>

        <p className="mt-1 text-[13px] text-stone-400">{course.instructor}</p>

        <div className="mt-3 flex items-center gap-3 text-xs text-stone-400">
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="font-semibold text-stone-700">{course.rating}</span>
          </span>
          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{course.duration}</span>
          <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{course.enrolled.toLocaleString()}</span>
        </div>

        <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between">
          <span className="text-sm font-bold text-stone-800">${course.price.toFixed(2)}</span>
          <span className="flex items-center gap-0.5 text-xs font-medium text-orange-600 opacity-0 group-hover:opacity-100 transition-opacity">
            View <ArrowUpRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}
