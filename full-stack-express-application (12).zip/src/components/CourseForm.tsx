import { useState } from 'react';
import { Save, X } from 'lucide-react';
import type { CourseFormData } from '../types';

const CATEGORIES = [
  'Web Development', 'Data Science', 'Design', 'Cloud & DevOps',
  'Mobile Development', 'Security', 'AI & Machine Learning',
  'Game Development', 'Database', 'Networking', 'Other',
];
const DURATIONS = ['2 weeks','3 weeks','4 weeks','5 weeks','6 weeks','7 weeks','8 weeks','9 weeks','10 weeks','12 weeks','16 weeks'];
const COLORS = [
  { n: 'Orange', v: '#ea580c' }, { n: 'Amber', v: '#d97706' },
  { n: 'Red', v: '#dc2626' }, { n: 'Rose', v: '#e11d48' },
  { n: 'Violet', v: '#7c3aed' }, { n: 'Blue', v: '#2563eb' },
  { n: 'Sky', v: '#0284c7' }, { n: 'Teal', v: '#0d9488' },
  { n: 'Green', v: '#16a34a' }, { n: 'Lime', v: '#65a30d' },
  { n: 'Stone', v: '#78716c' }, { n: 'Slate', v: '#475569' },
];

interface Props {
  initialData?: Partial<CourseFormData>;
  onSubmit: (d: CourseFormData) => void;
  onCancel: () => void;
  submitLabel?: string;
}

export default function CourseForm({ initialData, onSubmit, onCancel, submitLabel = 'Save Course' }: Props) {
  const [f, setF] = useState<CourseFormData>({
    title: initialData?.title ?? '',
    instructor: initialData?.instructor ?? '',
    category: initialData?.category ?? 'Web Development',
    duration: initialData?.duration ?? '8 weeks',
    level: initialData?.level ?? 'Beginner',
    price: initialData?.price ?? 0,
    description: initialData?.description ?? '',
    rating: initialData?.rating ?? 4,
    color: initialData?.color ?? '#ea580c',
  });
  const [err, setErr] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!f.title.trim()) e.title = 'Course title is required';
    if (!f.instructor.trim()) e.instructor = 'Instructor is required';
    if (!f.description.trim()) e.description = 'Description is required';
    else if (f.description.trim().length < 10) e.description = 'Min 10 characters';
    if (f.price < 0) e.price = 'Price cannot be negative';
    if (f.rating < 0 || f.rating > 5) e.rating = 'Rating must be 0–5';
    setErr(e);
    return !Object.keys(e).length;
  };

  const submit = (ev: React.FormEvent) => { ev.preventDefault(); if (validate()) onSubmit(f); };
  const set = (k: keyof CourseFormData, v: string | number) => {
    setF(p => ({ ...p, [k]: v }));
    if (err[k]) setErr(p => { const c = { ...p }; delete c[k]; return c; });
  };

  const cls = (k: string) =>
    `w-full px-4 py-2.5 bg-white border rounded-xl text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 transition-all ${
      err[k] ? 'border-red-300 focus:ring-red-200' : 'border-stone-200 focus:ring-orange-200 focus:border-orange-400'
    }`;

  return (
    <form onSubmit={submit} className="space-y-5">
      <div>
        <label className="block text-sm font-medium text-stone-700 mb-1.5">Course Title <span className="text-red-400">*</span></label>
        <input type="text" value={f.title} onChange={e => set('title', e.target.value)} placeholder="e.g. Full-Stack Web Development" className={cls('title')} />
        {err.title && <p className="mt-1 text-sm text-red-500">{err.title}</p>}
      </div>

      <div>
        <label className="block text-sm font-medium text-stone-700 mb-1.5">Instructor <span className="text-red-400">*</span></label>
        <input type="text" value={f.instructor} onChange={e => set('instructor', e.target.value)} placeholder="e.g. Dr. Jane Doe" className={cls('instructor')} />
        {err.instructor && <p className="mt-1 text-sm text-red-500">{err.instructor}</p>}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1.5">Category</label>
          <select value={f.category} onChange={e => set('category', e.target.value)} className={cls('category')}>
            {CATEGORIES.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1.5">Level</label>
          <select value={f.level} onChange={e => set('level', e.target.value as CourseFormData['level'])} className={cls('level')}>
            <option value="Beginner">🟢 Beginner</option>
            <option value="Intermediate">🟡 Intermediate</option>
            <option value="Advanced">🔴 Advanced</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1.5">Duration</label>
          <select value={f.duration} onChange={e => set('duration', e.target.value)} className={cls('duration')}>
            {DURATIONS.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1.5">Price ($)</label>
          <input type="number" min="0" step="0.01" value={f.price} onChange={e => set('price', parseFloat(e.target.value) || 0)} className={cls('price')} />
          {err.price && <p className="mt-1 text-sm text-red-500">{err.price}</p>}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-stone-700 mb-1.5">Description <span className="text-red-400">*</span></label>
        <textarea value={f.description} onChange={e => set('description', e.target.value)} placeholder="What will students learn..." rows={4} className={`${cls('description')} resize-none`} />
        {err.description && <p className="mt-1 text-sm text-red-500">{err.description}</p>}
      </div>

      <div>
        <label className="block text-sm font-medium text-stone-700 mb-1.5">
          Rating: <span className="text-orange-600 font-bold">{f.rating.toFixed(1)}</span> / 5
        </label>
        <input type="range" min="0" max="5" step="0.1" value={f.rating} onChange={e => set('rating', parseFloat(e.target.value))} className="w-full" />
        <div className="flex justify-between text-[11px] text-stone-400 mt-1"><span>0</span><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span></div>
      </div>

      <div>
        <label className="block text-sm font-medium text-stone-700 mb-2">Accent Color</label>
        <div className="flex flex-wrap gap-2">
          {COLORS.map(c => (
            <button key={c.v} type="button" onClick={() => set('color', c.v)} title={c.n}
              className={`w-8 h-8 rounded-full transition-all duration-200 ${f.color === c.v ? 'ring-2 ring-offset-2 ring-stone-400 scale-110' : 'opacity-50 hover:opacity-100 hover:scale-105'}`}
              style={{ backgroundColor: c.v }} />
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3 pt-5 border-t border-stone-100">
        <button type="submit" className="flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 transition-colors shadow-sm">
          <Save className="w-4 h-4" /> {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="flex items-center gap-2 px-6 py-2.5 bg-stone-100 text-stone-600 rounded-xl font-medium hover:bg-stone-200 transition-colors">
          <X className="w-4 h-4" /> Cancel
        </button>
      </div>
    </form>
  );
}
