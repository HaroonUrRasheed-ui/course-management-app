export interface Course {
  _id: string;
  title: string;
  instructor: string;
  category: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  price: number;
  description: string;
  rating: number;
  enrolled: number;
  color: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  _id: string;
  username: string;
  email: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export type CourseFormData = Omit<Course, '_id' | 'createdBy' | 'createdAt' | 'updatedAt' | 'enrolled'>;
