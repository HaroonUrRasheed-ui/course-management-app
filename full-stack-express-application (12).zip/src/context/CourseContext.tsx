import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Course, CourseFormData } from '../types';

interface CourseContextType {
  courses: Course[];
  getById: (id: string) => Course | undefined;
  create: (data: CourseFormData, userId: string) => Course;
  update: (id: string, data: Partial<CourseFormData>) => Course | null;
  remove: (id: string) => boolean;
}

const Ctx = createContext<CourseContextType | null>(null);
const KEY = 'learnstack_courses';
const PALETTE = ['#ea580c','#d97706','#dc2626','#e11d48','#7c3aed','#2563eb','#0284c7','#0d9488','#16a34a','#65a30d'];

const SEED: Course[] = [
  {
    _id: 's1', title: 'Full-Stack Web Development with Node.js',
    instructor: 'Dr. Sarah Mitchell', category: 'Web Development',
    duration: '12 weeks', level: 'Intermediate', price: 49.99,
    description: 'Master full-stack web development using Node.js, Express, MongoDB, and modern front-end frameworks. Build real-world projects with hands-on labs and quizzes.',
    rating: 4.8, enrolled: 2340, color: '#2563eb',
    createdBy: 'system', createdAt: '2025-09-01T08:00:00Z', updatedAt: '2025-09-01T08:00:00Z',
  },
  {
    _id: 's2', title: 'Python for Data Science & Machine Learning',
    instructor: 'Prof. James Carter', category: 'Data Science',
    duration: '10 weeks', level: 'Beginner', price: 39.99,
    description: 'Learn Python from zero to hero. Dive into NumPy, Pandas, Matplotlib, Scikit-learn, and build predictive models with real-world datasets.',
    rating: 4.7, enrolled: 5120, color: '#16a34a',
    createdBy: 'system', createdAt: '2025-08-15T10:30:00Z', updatedAt: '2025-08-15T10:30:00Z',
  },
  {
    _id: 's3', title: 'UI/UX Design Fundamentals',
    instructor: 'Emily Zhang', category: 'Design',
    duration: '6 weeks', level: 'Beginner', price: 29.99,
    description: 'Understand design thinking, wireframing, prototyping, and user research. Use Figma to create stunning interfaces that delight users.',
    rating: 4.5, enrolled: 1890, color: '#e11d48',
    createdBy: 'system', createdAt: '2025-07-20T14:00:00Z', updatedAt: '2025-07-20T14:00:00Z',
  },
  {
    _id: 's4', title: 'Cloud Computing with AWS',
    instructor: 'Michael Torres', category: 'Cloud & DevOps',
    duration: '8 weeks', level: 'Advanced', price: 59.99,
    description: 'Deploy, manage, and scale applications on Amazon Web Services. Covers EC2, S3, Lambda, DynamoDB, CloudFormation, and CI/CD pipelines.',
    rating: 4.6, enrolled: 980, color: '#d97706',
    createdBy: 'system', createdAt: '2025-10-05T09:15:00Z', updatedAt: '2025-10-05T09:15:00Z',
  },
  {
    _id: 's5', title: 'Mobile App Development with React Native',
    instructor: 'Anna Kowalski', category: 'Mobile Development',
    duration: '9 weeks', level: 'Intermediate', price: 44.99,
    description: 'Build cross-platform mobile applications for iOS and Android using React Native. Includes navigation, state management, and app store deployment.',
    rating: 4.4, enrolled: 1560, color: '#7c3aed',
    createdBy: 'system', createdAt: '2025-06-10T11:45:00Z', updatedAt: '2025-06-10T11:45:00Z',
  },
  {
    _id: 's6', title: 'Cybersecurity Essentials',
    instructor: 'Robert Nguyen', category: 'Security',
    duration: '7 weeks', level: 'Beginner', price: 34.99,
    description: 'Learn to identify vulnerabilities, secure networks, and implement best practices. Covers encryption, firewalls, ethical hacking, and incident response.',
    rating: 4.9, enrolled: 3200, color: '#dc2626',
    createdBy: 'system', createdAt: '2025-11-01T16:00:00Z', updatedAt: '2025-11-01T16:00:00Z',
  },
];

function load(): Course[] {
  try { const d = localStorage.getItem(KEY); if (d) return JSON.parse(d); localStorage.setItem(KEY, JSON.stringify(SEED)); return SEED; } catch { return SEED; }
}
function save(c: Course[]) { localStorage.setItem(KEY, JSON.stringify(c)); }

export function CourseProvider({ children }: { children: ReactNode }) {
  const [courses, setCourses] = useState<Course[]>(load);

  const getById = useCallback((id: string) => courses.find(c => c._id === id), [courses]);

  const create = useCallback((data: CourseFormData, userId: string) => {
    const now = new Date().toISOString();
    const c: Course = { ...data, _id: crypto.randomUUID(), enrolled: 0, color: data.color || PALETTE[Math.floor(Math.random() * PALETTE.length)], createdBy: userId, createdAt: now, updatedAt: now };
    setCourses(prev => { const n = [...prev, c]; save(n); return n; });
    return c;
  }, []);

  const update = useCallback((id: string, data: Partial<CourseFormData>) => {
    let out: Course | null = null;
    setCourses(prev => { const i = prev.findIndex(c => c._id === id); if (i === -1) return prev; out = { ...prev[i], ...data, updatedAt: new Date().toISOString() }; const n = [...prev]; n[i] = out; save(n); return n; });
    return out;
  }, []);

  const remove = useCallback((id: string) => {
    let ok = false;
    setCourses(prev => { const n = prev.filter(c => c._id !== id); ok = n.length < prev.length; save(n); return n; });
    return ok;
  }, []);

  return <Ctx.Provider value={{ courses, getById, create, update, remove }}>{children}</Ctx.Provider>;
}

export function useCourses() { const c = useContext(Ctx); if (!c) throw new Error('useCourses must be inside CourseProvider'); return c; }
