import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useCourses } from '../context/CourseContext';
import CourseCard from '../components/CourseCard';
import { Plus, Search, SlidersHorizontal, GraduationCap, LayoutGrid, List, Star, Clock, Users, DollarSign } from 'lucide-react';

export default function CoursesListPage() {
  const { courses } = useCourses();
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('All');
  const [lvlFilter, setLvlFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'title' | 'rating' | 'price-low' | 'price-high'>('newest');
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const cats = useMemo(() => ['All', ...Array.from(new Set(courses.map(c => c.category))).sort()], [courses]);

  const filtered = useMemo(() => {
    let r = [...courses];
    if (search.trim()) { const q = search.toLowerCase(); r = r.filter(c => c.title.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)); }
    if (catFilter !== 'All') r = r.filter(c => c.category === catFilter);
    if (lvlFilter !== 'All') r = r.filter(c => c.level === lvlFilter);
    switch (sortBy) {
      case 'newest': r.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)); break;
      case 'oldest': r.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)); break;
      case 'title': r.sort((a, b) => a.title.localeCompare(b.title)); break;
      case 'rating': r.sort((a, b) => b.rating - a.rating); break;
      case 'price-low': r.sort((a, b) => a.price - b.price); break;
      case 'price-high': r.sort((a, b) => b.price - a.price); break;
    }
    return r;
  }, [courses, search, catFilter, lvlFilter, sortBy]);

  const catEmoji: Record<string, string> = { 'Web Development': '🌐', 'Data Science': '📊', Design: '🎨', 'Cloud & DevOps': '☁️', 'Mobile Development': '📱', Security: '🔒' };
  const levelDot: Record<string, string> = { Beginner: 'bg-emerald-400', Intermediate: 'bg-amber-400', Advanced: 'bg-red-400' };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-stone-900">All Courses</h1>
          <p className="text-stone-500 mt-1">{courses.length} course{courses.length !== 1 ? 's' : ''} available</p>
        </div>
        <Link to="/courses/new" className="flex items-center gap-2 px-5 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 transition-colors self-start shadow-sm">
          <Plus className="w-4 h-4" /> New Course
        </Link>
      </div>

      <div className="bg-white rounded-2xl border border-stone-200 p-4 mb-6 shadow-sm">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search courses..."
              className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 placeholder-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-orange-200 focus:border-orange-400" />
          </div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-stone-400 flex-shrink-0" />
            <select value={catFilter} onChange={e => setCatFilter(e.target.value)} className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-700 text-sm focus:outline-none focus:ring-2 focus:ring-orange-200">
              {cats.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <select value={lvlFilter} onChange={e => setLvlFilter(e.target.value)} className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-700 text-sm focus:outline-none focus:ring-2 focus:ring-orange-200">
            <option value="All">All Levels</option>
            <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
          </select>
          <select value={sortBy} onChange={e => setSortBy(e.target.value as typeof sortBy)} className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-700 text-sm focus:outline-none focus:ring-2 focus:ring-orange-200">
            <option value="newest">Newest</option><option value="oldest">Oldest</option>
            <option value="title">Title A-Z</option><option value="rating">Top Rated</option>
            <option value="price-low">Price ↑</option><option value="price-high">Price ↓</option>
          </select>
          <div className="flex bg-stone-100 rounded-xl p-1 self-start">
            <button onClick={() => setView('grid')} className={`p-2 rounded-lg transition-colors ${view === 'grid' ? 'bg-white text-stone-800 shadow-sm' : 'text-stone-400 hover:text-stone-600'}`}><LayoutGrid className="w-4 h-4" /></button>
            <button onClick={() => setView('list')} className={`p-2 rounded-lg transition-colors ${view === 'list' ? 'bg-white text-stone-800 shadow-sm' : 'text-stone-400 hover:text-stone-600'}`}><List className="w-4 h-4" /></button>
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-16 text-center shadow-sm">
          <GraduationCap className="w-14 h-14 text-stone-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-stone-500 mb-2">{courses.length === 0 ? 'No courses yet' : 'No matches found'}</h3>
          <p className="text-stone-400 mb-4">{courses.length === 0 ? 'Create your first course.' : 'Try different filters.'}</p>
          {courses.length === 0 && <Link to="/courses/new" className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 shadow-sm"><Plus className="w-4 h-4" /> New Course</Link>}
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(c => <CourseCard key={c._id} course={c} />)}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(c => (
            <Link key={c._id} to={`/courses/${c._id}`} className="flex items-center gap-4 bg-white border border-stone-200 rounded-2xl p-4 hover:border-orange-300 hover:shadow-sm transition-all group">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0 bg-stone-50 border border-stone-100">
                {catEmoji[c.category] || '📚'}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-stone-800 font-semibold group-hover:text-orange-600 transition-colors truncate">{c.title}</h3>
                <p className="text-sm text-stone-400">{c.instructor} · <span className="inline-flex items-center gap-1"><span className={`w-1.5 h-1.5 rounded-full inline-block ${levelDot[c.level]}`} />{c.level}</span></p>
              </div>
              <div className="hidden sm:flex items-center gap-5 text-xs text-stone-400 flex-shrink-0">
                <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />{c.rating}</span>
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{c.duration}</span>
                <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{c.enrolled.toLocaleString()}</span>
                <span className="font-bold text-stone-700 flex items-center gap-0.5"><DollarSign className="w-3.5 h-3.5" />{c.price.toFixed(2)}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
