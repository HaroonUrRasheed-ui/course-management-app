import { useParams, useNavigate, Link } from 'react-router-dom';
import { useCourses } from '../context/CourseContext';
import CourseForm from '../components/CourseForm';
import type { CourseFormData } from '../types';
import { Edit, ArrowLeft, GraduationCap } from 'lucide-react';

export default function EditCoursePage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const { getById, update } = useCourses();

  const c = id ? getById(id) : undefined;

  if (!c) return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <GraduationCap className="w-16 h-16 text-stone-300 mx-auto mb-4" />
      <h1 className="text-2xl font-bold text-stone-800 mb-2">Course Not Found</h1>
      <p className="text-stone-500 mb-6">The course you're trying to edit doesn't exist.</p>
      <Link to="/courses" className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 shadow-sm">
        <ArrowLeft className="w-4 h-4" /> Back to Courses
      </Link>
    </div>
  );

  const submit = (data: CourseFormData) => { if (id) { update(id, data); nav(`/courses/${id}`); } };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link to={`/courses/${c._id}`} className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-700 transition-colors mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to Course
      </Link>
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-amber-100 p-2.5 rounded-xl"><Edit className="w-5 h-5 text-amber-600" /></div>
          <h1 className="text-3xl font-extrabold text-stone-900">Edit Course</h1>
        </div>
        <p className="text-stone-500 ml-[52px]">Updating "<strong className="text-stone-700">{c.title}</strong>"</p>
      </div>
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-sm">
        <CourseForm initialData={c} onSubmit={submit} onCancel={() => nav(`/courses/${c._id}`)} submitLabel="Update Course" />
      </div>
    </div>
  );
}
