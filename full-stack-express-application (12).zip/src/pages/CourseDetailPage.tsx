import { useParams, useNavigate, Link } from 'react-router-dom';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';
import { ArrowLeft, Edit, Trash2, Star, Clock, Users, DollarSign, Calendar, GraduationCap, Signal } from 'lucide-react';

const catEmoji: Record<string, string> = {
  'Web Development': '🌐', 'Data Science': '📊', Design: '🎨',
  'Cloud & DevOps': '☁️', 'Mobile Development': '📱', Security: '🔒',
};

export default function CourseDetailPage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const { getById, remove } = useCourses();
  const { user } = useAuth();
  const [confirmDel, setConfirmDel] = useState(false);

  const c = id ? getById(id) : undefined;

  if (!c) return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <GraduationCap className="w-16 h-16 text-stone-300 mx-auto mb-4" />
      <h1 className="text-2xl font-bold text-stone-800 mb-2">Course Not Found</h1>
      <p className="text-stone-500 mb-6">This course may have been removed.</p>
      <Link to="/courses" className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 shadow-sm">
        <ArrowLeft className="w-4 h-4" /> Back to Courses
      </Link>
    </div>
  );

  const handleDelete = () => { if (id) { remove(id); nav('/courses'); } };
  const isOwner = c.createdBy === user?._id || c.createdBy === 'system';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link to="/courses" className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-700 transition-colors mb-8">
        <ArrowLeft className="w-4 h-4" /> Back to Courses
      </Link>

      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm">
        <div className="h-48 sm:h-56 relative overflow-hidden bg-stone-50 flex items-center justify-center">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl flex items-center justify-center text-6xl sm:text-7xl"
            style={{ backgroundColor: c.color + '15', border: `2px solid ${c.color}25` }}>
            {catEmoji[c.category] || '📚'}
          </div>

          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-4 py-2 rounded-full shadow-sm border border-stone-100 flex items-center gap-1">
            <DollarSign className="w-4 h-4 text-stone-600" />
            <span className="text-xl font-extrabold text-stone-800">{c.price.toFixed(2)}</span>
          </div>

          <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-white/90 backdrop-blur px-3 py-1.5 rounded-full shadow-sm border border-stone-100">
            <Signal className="w-4 h-4 text-stone-500" />
            <span className="text-sm font-semibold text-stone-600">{c.level}</span>
          </div>
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg" style={{ color: c.color, backgroundColor: c.color + '12' }}>
                {c.category}
              </span>
              <h1 className="mt-3 text-2xl sm:text-3xl font-extrabold text-stone-900 leading-tight">{c.title}</h1>
              <p className="mt-1 text-lg text-stone-500">by <span className="text-stone-700 font-medium">{c.instructor}</span></p>
            </div>
            {isOwner && (
              <div className="flex items-center gap-2 flex-shrink-0">
                <Link to={`/courses/${c._id}/edit`} className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-xl text-sm font-semibold hover:bg-orange-500 transition-colors shadow-sm">
                  <Edit className="w-4 h-4" /> Edit
                </Link>
                <button onClick={() => setConfirmDel(true)} className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 border border-red-200 rounded-xl text-sm font-semibold hover:bg-red-100 transition-colors">
                  <Trash2 className="w-4 h-4" /> Delete
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-100">
              <div className="flex items-center gap-2 text-stone-400 text-sm mb-1.5"><Star className="w-4 h-4" /> Rating</div>
              <div className="flex items-center gap-1">
                {[1,2,3,4,5].map(s => <Star key={s} className={`w-4 h-4 ${s <= Math.round(c.rating) ? 'text-amber-400 fill-amber-400' : 'text-stone-200'}`} />)}
                <span className="ml-1 text-sm text-stone-700 font-bold">{c.rating}</span>
              </div>
            </div>
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-100">
              <div className="flex items-center gap-2 text-stone-400 text-sm mb-1.5"><Clock className="w-4 h-4" /> Duration</div>
              <span className="text-stone-800 font-bold">{c.duration}</span>
            </div>
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-100">
              <div className="flex items-center gap-2 text-stone-400 text-sm mb-1.5"><Users className="w-4 h-4" /> Enrolled</div>
              <span className="text-stone-800 font-bold">{c.enrolled.toLocaleString()}</span>
            </div>
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-100">
              <div className="flex items-center gap-2 text-stone-400 text-sm mb-1.5"><Calendar className="w-4 h-4" /> Added</div>
              <span className="text-stone-700 font-semibold text-sm">{new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-bold text-stone-800 mb-3">About This Course</h2>
            <p className="text-stone-500 leading-relaxed">{c.description}</p>
          </div>
        </div>
      </div>

      {confirmDel && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl border border-stone-200 p-6 max-w-sm w-full shadow-xl">
            <div className="text-center">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4"><Trash2 className="w-6 h-6 text-red-500" /></div>
              <h3 className="text-lg font-bold text-stone-800 mb-2">Delete Course</h3>
              <p className="text-stone-500 text-sm mb-6">Delete "<strong className="text-stone-700">{c.title}</strong>"? This cannot be undone.</p>
              <div className="flex gap-3">
                <button onClick={() => setConfirmDel(false)} className="flex-1 py-2.5 bg-stone-100 text-stone-600 rounded-xl font-medium hover:bg-stone-200 transition-colors">Cancel</button>
                <button onClick={handleDelete} className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-medium hover:bg-red-500 transition-colors">Delete</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
