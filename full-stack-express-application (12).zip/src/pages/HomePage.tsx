import { Link } from 'react-router-dom';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import CourseCard from '../components/CourseCard';
import {
  GraduationCap, Shield, Database, Layout, Server, Code,
  ArrowRight, Layers, BookOpen, Star, Users,
} from 'lucide-react';

export default function HomePage() {
  const { courses } = useCourses();
  const { isAuthenticated } = useAuth();

  const tech = [
    { icon: Server,   label: 'Node.js + Express',  desc: 'Backend server & routing' },
    { icon: Database,  label: 'MongoDB + Mongoose', desc: 'NoSQL database & ODM' },
    { icon: Layout,    label: 'EJS Templates',      desc: 'Server-side view engine' },
    { icon: Code,      label: 'TailwindCSS',        desc: 'Utility-first CSS' },
    { icon: Shield,    label: 'Passport.js',        desc: 'Auth (Local Strategy)' },
    { icon: Layers,    label: 'RESTful API',        desc: 'Full CRUD endpoints' },
  ];

  const totalStudents = courses.reduce((s, c) => s + c.enrolled, 0);
  const avgRating = courses.length ? (courses.reduce((s, c) => s + c.rating, 0) / courses.length).toFixed(1) : '0';

  return (
    <div>
      {/* ── HERO ── */}
      <section className="relative overflow-hidden bg-gradient-to-b from-orange-50 via-amber-50/50 to-stone-50 py-24 sm:py-32">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-orange-200/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-amber-200/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white border border-orange-200 px-4 py-1.5 rounded-full mb-8 shadow-sm">
            <GraduationCap className="w-4 h-4 text-orange-600" />
            <span className="text-sm text-orange-700 font-medium">Web Engineering Assignment — Apr 20, 2026</span>
          </div>

          <h1 className="text-5xl sm:text-7xl font-black text-stone-900 mb-6 tracking-tight leading-[1.1]">
            Learn<span className="text-orange-600">Stack</span>
          </h1>

          <p className="text-lg sm:text-xl text-stone-500 max-w-xl mx-auto mb-10 leading-relaxed">
            A full-stack course management app built with
            <strong className="text-stone-700"> Node.js, Express, MongoDB, EJS, TailwindCSS </strong>
            and <strong className="text-stone-700">Passport.js</strong>.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            {isAuthenticated ? (
              <>
                <Link to="/courses" className="flex items-center gap-2 px-8 py-3.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 transition-colors shadow-md shadow-orange-600/20">
                  Browse Courses <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/courses/new" className="px-8 py-3.5 bg-white text-stone-700 rounded-xl font-semibold border border-stone-200 hover:bg-stone-50 transition-colors shadow-sm">+ Create Course</Link>
              </>
            ) : (
              <>
                <Link to="/register" className="flex items-center gap-2 px-8 py-3.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 transition-colors shadow-md shadow-orange-600/20">
                  Get Started <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/login" className="px-8 py-3.5 bg-white text-stone-700 rounded-xl font-semibold border border-stone-200 hover:bg-stone-50 transition-colors shadow-sm">Sign In</Link>
              </>
            )}
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 max-w-sm mx-auto gap-6">
            {[
              { icon: BookOpen, val: courses.length, label: 'Courses' },
              { icon: Star,     val: avgRating,      label: 'Avg Rating' },
              { icon: Users,    val: totalStudents.toLocaleString(), label: 'Enrolled' },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="w-10 h-10 bg-white rounded-xl border border-stone-200 flex items-center justify-center mx-auto mb-2 shadow-sm">
                  <s.icon className="w-5 h-5 text-orange-600" />
                </div>
                <div className="text-xl font-bold text-stone-800">{s.val}</div>
                <div className="text-xs text-stone-400 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TECH STACK ── */}
      <section className="py-20 bg-white border-y border-stone-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-stone-900 mb-3">Technology Stack</h2>
            <p className="text-stone-500 max-w-lg mx-auto">Built with modern web technologies following MVC architecture.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {tech.map(t => (
              <div key={t.label} className="bg-stone-50 border border-stone-100 rounded-2xl p-5 text-center hover:border-orange-200 hover:bg-orange-50/30 transition-all group">
                <div className="bg-white w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 border border-stone-100 shadow-sm group-hover:border-orange-200">
                  <t.icon className="w-5 h-5 text-orange-600" />
                </div>
                <h3 className="text-sm font-semibold text-stone-800 mb-1">{t.label}</h3>
                <p className="text-xs text-stone-400">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED COURSES ── */}
      <section className="py-20 bg-stone-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-stone-900 mb-2">Featured Courses</h2>
              <p className="text-stone-500">Latest additions to the catalog</p>
            </div>
            {isAuthenticated && (
              <Link to="/courses" className="hidden sm:flex items-center gap-1 text-orange-600 hover:text-orange-500 font-semibold transition-colors">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            )}
          </div>

          {courses.length === 0 ? (
            <div className="bg-white rounded-2xl border border-stone-200 p-16 text-center shadow-sm">
              <GraduationCap className="w-14 h-14 text-stone-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-stone-500 mb-2">No courses yet</h3>
              <p className="text-stone-400 mb-6">Be the first to create a course!</p>
              {isAuthenticated && (
                <Link to="/courses/new" className="inline-flex items-center gap-2 px-6 py-2.5 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-500 shadow-sm">Create Course</Link>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.slice(-6).reverse().map(c => <CourseCard key={c._id} course={c} />)}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
