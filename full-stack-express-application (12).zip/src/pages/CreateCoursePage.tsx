import { useNavigate } from 'react-router-dom';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import CourseForm from '../components/CourseForm';
import type { CourseFormData } from '../types';
import { Plus } from 'lucide-react';

export default function CreateCoursePage() {
  const nav = useNavigate();
  const { create } = useCourses();
  const { user } = useAuth();

  const submit = (data: CourseFormData) => {
    const c = create(data, user?._id || 'anon');
    nav(`/courses/${c._id}`);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-orange-100 p-2.5 rounded-xl"><Plus className="w-5 h-5 text-orange-600" /></div>
          <h1 className="text-3xl font-extrabold text-stone-900">Create New Course</h1>
        </div>
        <p className="text-stone-500 ml-[52px]">Fill in the details to add a course to the catalog.</p>
      </div>
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-sm">
        <CourseForm onSubmit={submit} onCancel={() => nav('/courses')} submitLabel="Create Course" />
      </div>
    </div>
  );
}
