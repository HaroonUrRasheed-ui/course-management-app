import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CourseProvider } from './context/CourseContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import CoursesListPage from './pages/CoursesListPage';
import CourseDetailPage from './pages/CourseDetailPage';
import CreateCoursePage from './pages/CreateCoursePage';
import EditCoursePage from './pages/EditCoursePage';

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <CourseProvider>
          <div className="min-h-screen bg-[#faf9f7] flex flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/courses" element={<ProtectedRoute><CoursesListPage /></ProtectedRoute>} />
                <Route path="/courses/new" element={<ProtectedRoute><CreateCoursePage /></ProtectedRoute>} />
                <Route path="/courses/:id" element={<ProtectedRoute><CourseDetailPage /></ProtectedRoute>} />
                <Route path="/courses/:id/edit" element={<ProtectedRoute><EditCoursePage /></ProtectedRoute>} />
              </Routes>
            </main>
            <Footer />
          </div>
        </CourseProvider>
      </AuthProvider>
    </Router>
  );
}
